 "/usr/bin/java" -jar server.jar "/media/sabit/Data/@CODE/Java/AKash/releases/v0.1/akash.db"
